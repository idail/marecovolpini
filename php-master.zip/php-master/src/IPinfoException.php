<?php

namespace ipinfo\ipinfo;

use Exception;

class IPinfoException extends Exception
{
}
