<?php
require_once 'geo.php';

// Example 
$ip  = '';  // coloque aqui o ip que vocë deseja, se deixar em branco ira pega o ip da sua internet
$geo = new Geo($ip);
echo "IP: $ip " .$geo->get();

